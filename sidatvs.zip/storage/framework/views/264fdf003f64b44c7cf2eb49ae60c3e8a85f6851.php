

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Form Input SKET</h1>
    </div>
    <div class="section-body">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <p>Gagal : </p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if(Session::has('gagal')): ?>
        <div class="alert alert-danger">
            <?php echo e(Session::get('gagal')); ?>

        </div>
        <?php endif; ?>
        <?php if(Session::has('berhasil')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('berhasil')); ?>

        </div>
        <?php endif; ?>
        <div class="col-lg-12 mb-3" style="padding-left: 0; padding-right: 0;">
            <form action="<?php echo e(route('post.sket')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="">Nama</label>
                    <input type="text" class="form-control" name="nama" placeholder="Masukkan nama" required>
                </div>
                <div class="form-group">
                    <label for="">NPWP</label>
                    <input type="text" class="form-control" placeholder="Masukkan nomor NPWP" name="npwp" required>
                </div>
                <div class="form-group">
                    <label for="">Nomor SKET</label>
                    <input type="text" class="form-control" placeholder="Masukkan nomor sket" name="no_sket" required>
                </div>
                <div class="form-group">
                    <label for="">Nomor LPAD</label>
                    <input type="text" class="form-control" placeholder="Masukkan nomor lpad" name="no_lpad" required>
                </div>
                <div class="form-group">
                    <label for="">Tanggal</label>
                    <input type="date" class="form-control" name="tanggal" required>
                </div>
                <div class="form-group">
                    <label for="">Nominal</label>
                    <input type="number" class="form-control" min="0" placeholder="Masukkan nominal" name="nominal" required>
                </div>
                <div class="form-group" style="text-align: center;">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('kpp.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sidatvs\resources\views/kpp/pages/listsket.blade.php ENDPATH**/ ?>