

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Gunakan SKET</h1>
    </div>
    <div class="section-body">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <p>Gagal : </p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if(Session::has('gagal')): ?>
        <div class="alert alert-danger">
            <?php echo e(Session::get('gagal')); ?>

        </div>
        <?php endif; ?>
        <?php if(Session::has('berhasil')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('berhasil')); ?>

        </div>
        <?php endif; ?>
        <div class="col-lg-12" style="padding-left: 0; padding-right: 0;">
            <div class="form-group">
                <label for="">No. SKET</label>
                <input type="text" class="form-control" placeholder="Masukkan nomor sket" id="keyword" required>
            </div>
            <div class="form-group" style="text-align: center;">
                <button class="btn btn-success" onclick="cariData()"><i class="fas fa-search"></i> Cari</button>
            </div>
        </div>
        <div class="row" style="margin-left: 0; padding-right: 0; width:100%" id="hasil">
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('bpn.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sidatvs\resources\views/bpn/pages/gunakansket.blade.php ENDPATH**/ ?>