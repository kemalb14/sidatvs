

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Data Petugas KPP</h1>
    </div>
    <div class="section-body">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <p>Gagal : </p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if(Session::has('gagal')): ?>
        <div class="alert alert-danger">
            <?php echo e(Session::get('gagal')); ?>

        </div>
        <?php endif; ?>
        <?php if(Session::has('berhasil')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('berhasil')); ?>

        </div>
        <?php endif; ?>
        <div class="col-lg-12 mb-3" style="padding-left: 0; padding-right: 0;">
        <button class="btn btn-success" onclick="tambahKpp()"><i class="fas fa-plus mr-1"></i>Tambah Data</button>
        </div>
        <table class="table table-striped tabel">
            <thead>
                <tr style="text-align: center;">
                    <th>No</th>
                    <th>Nama</th>
                    <th>Username</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $kpp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr style="text-align: center;">
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($k->name); ?></td>
                    <td><?php echo e($k->username); ?></td>
                    <td>
                        <button class="btn btn-primary" onclick="editKpp('<?php echo e($k->id); ?>')"><i class="fas fa-pencil-alt"></i> Ubah</button>
                        <button class="btn btn-warning" onclick="editPassKpp('<?php echo e($k->id); ?>')"><i class="fas fa-pencil-alt"></i> Ubah Password</button>
                        <a href="<?php echo e(route('hapus.petugas.kpp', ['id' => $k->id])); ?>" class="btn btn-danger" onclick="return confirm('Yakin melanjutkan hapus data ? ')"><i class="fas fa-trash"></i> Hapus</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr style="text-align: center;">
                    <td colspan="4">Tidak Ada Data</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sidatvs\resources\views/admin/pages/listkpp.blade.php ENDPATH**/ ?>