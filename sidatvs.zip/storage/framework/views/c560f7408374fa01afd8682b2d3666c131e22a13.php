

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Dashboard</h1>
    </div>
    <div class="section-body">
        <table class="table table-striped tabel">
            <thead>
                <tr style="text-align: center;">
                    <th>No</th>
                    <th>Nama</th>
                    <th>NPWP</th>
                    <th>No. SKET</th>
                    <th>Penerima Hak</th>
                    <th>Tanggal</th>
                    <th>Nominal</th>
                    <th>Status</th>
                    <th>No. Sertifikat</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $sket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="text-align: center;">
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($s->nama); ?></td>
                    <td><?php echo e($s->npwp); ?></td>
                    <td><?php echo e($s->no_sket); ?></td>
                    <td><?php echo e($s->penerima_hak); ?></td>
                    <td><?php echo e($s->tanggal); ?></td>
                    <td><?php echo e($s->nominal); ?></td>
                    <td><?php echo e($s->status); ?></td>
                    <td><?php echo e($s->no_sertifikat); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sidatvs\resources\views/admin/pages/home.blade.php ENDPATH**/ ?>