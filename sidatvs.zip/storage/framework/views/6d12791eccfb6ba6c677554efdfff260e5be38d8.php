

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Dashboard</h1>
    </div>
    <div class="section-body">

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('kpp.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sidatvs\resources\views/kpp/pages/home.blade.php ENDPATH**/ ?>